// import React, { Component } from 'react'

/*export default class Counter extends Component {
    constructor(props){
      super(props)
      this.state ={
        count:0,
      }
    }

    incrimaenCount = () => {
        this.setState({count: this.state.count + 1})
    }
    decrimaenCount = () => {
        this.setState({count:this.state.count -1})
    }
  render() {
    return (
      <div>
      <h2>counter Value: {this.state.count}</h2>
      <button onClick={this.incrimaenCount}>Incriment</button>
      <button onClick={this.decrimaenCount}>Decriment</button>
      </div>
    )
  }
}*/
import React, { useState } from 'react'

export default function Counter() {
    const [count, setCount] = useState(0);
    const [step, setStep] = useState(1);
    const incrimaenttwist = () =>{
        setCount(prevCount => prevCount+1);
        setCount(prevCount => prevCount+1);
    }
  return (
    <div>
    <h2> counter value {count} </h2>
    <input type='number' value={step} onChange={(e) => setStep(parseInt(e.target.value))}/>
    <button onClick={incrimaenttwist}>Incriment</button>
    <button onClick={() => setCount(count-step)}>Decriment</button>
    </div>
  )
}

