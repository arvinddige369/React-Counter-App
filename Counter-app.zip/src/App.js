import './App.css';
import Counter from './componant/Counter';

function App() {
  return (
    <div className="App">
      <Counter/>
    </div>
  );
}

export default App;
